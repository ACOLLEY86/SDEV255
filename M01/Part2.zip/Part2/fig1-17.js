/* Written by Anthony Colley
Figure 1.17 */

for (var i=0; i <= 5; i++) console.log("i = " + i);