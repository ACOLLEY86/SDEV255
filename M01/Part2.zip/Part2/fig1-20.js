/* Written by Anthony Colley
Figure 1.20 */

// function definition
function display_10_first_integers() {
    for (var i=0; i <= 10; i++) console.log("i = " + i);
  }
  // function call
  console.log("*** 1st call *** ");
  display_10_first_integers(); 
  console.log("*** 2nd call *** ");
  display_10_first_integers(); 
  console.log("*** 3rd call *** ");
  display_10_first_integers();  