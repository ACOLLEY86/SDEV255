/* Written By Anthony Colley
Figure 2.25 */

var s = new String("I'll love JavaScript");
console.log("s =", s);