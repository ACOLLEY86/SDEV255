/* Written By Anthony Colley
Figure 2.23 */

var s = 'String 1';
console.log("s =", s);