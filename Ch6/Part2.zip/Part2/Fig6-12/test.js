/* Written By Anthony Colley
Figure 6.12 */

var colors = require("colors");
console.log("colors = ", colors);