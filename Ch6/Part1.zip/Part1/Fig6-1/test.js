/* Written By Anthony Colley
Figure 6.1 */

var mod1 = require("./module1.js");  
// or require("./module1") without specifying the .js extension
console.log("mod1 =", mod1);