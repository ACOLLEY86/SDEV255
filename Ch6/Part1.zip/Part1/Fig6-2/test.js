/* Written By Anthony Colley
Figure 6.2 */

var mod1 = require("module1.js");  // or require("module1")
console.log("mod1 =", mod1);