/* Written By Anthony Colley
Figure 5.7 */

const Element = {
    data() {
      return {
      }
    },
    template : `
    `,
  }
  export default Element;