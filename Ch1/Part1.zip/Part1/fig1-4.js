/* Written by Anthony Colley
Figure 1.4 */

console.log("This is a warning message displayed by JavaScript");